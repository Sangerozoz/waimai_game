const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const ts=require('/Applications/Cocos/Creator/3.8.8/CocosCreator.app/Contents/Resources/app.asar.unpacked/node_modules/typescript');

// Exercise the actual gesture methods. Only the engine/renderer boundary is replaced;
// a full project typecheck and built-browser checks cover that boundary separately.
const source=fs.readFileSync(path.join(__dirname,'../assets/scripts/map-sample/CityMap.ts'),'utf8');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2015,module:ts.ModuleKind.CommonJS}}).outputText;
const scope={exports:{},require(id){
 if(id==='cc')return {};
 if(id==='./SampleUI')return {C:{blue:'blue',gold:'gold',green:'green'}};
 if(id==='./CityExtent')return require(path.join(path.dirname(process.env.MAP_ROUTER_MODULE),'CityExtent.js'));
 throw new Error(`Unexpected dependency: ${id}`);
}};
vm.runInNewContext(compiled,scope,{filename:'CityMap.js'});
const {CityMap}=scope.exports;

function camera(scale=1){
 const city=Object.create(CityMap.prototype);
 Object.assign(city,{scale,offset:[0,0],touchPoints:new Map(),follow:false});
 city.sync=()=>{};
 city.local=e=>e.point;
 return city;
}
const touch=(id,x,y=0)=>({getID:()=>id,point:[x,y]});

test('translating both fingers moves the map in the same direction without changing zoom',()=>{
 const city=camera();
 city.touchStart(touch(1,-100));city.touchStart(touch(2,100));
 city.touchMove(touch(1,0));city.touchMove(touch(2,200));
 assert.equal(city.scale,1);
 assert.deepEqual(Array.from(city.offset),[100,0]);
});

function boundedCamera(height=1348){
 const city=Object.create(CityMap.prototype),node={setPosition(){},setScale(){}};
 Object.assign(city,{scale:.6,offset:[0,0],mapHeight:height,data:{width:11672,height:12245,playBounds:{minX:-4530,maxX:-570,minY:-1410,maxY:1110}},riderPoint:[-1540,-130],riderAngle:0,routes:[],selected:0,follow:false,touchPoints:new Map(),world:node,scaleLabel:{},labels:[],poiDots:[],rider:{...node},startPin:{...node},endPin:{...node}});
 city.drawMajorRoads=city.drawRoutes=city.syncDetails=()=>{};city.local=e=>e.point;
 return city;
}
function assertViewport(city){
 const b=city.data.playBounds,[x,y]=city.offset,s=city.scale,h=city.mapHeight;
 assert.ok((-360-x)/s>=b.minX-1e-8);assert.ok((360-x)/s<=b.maxX+1e-8);
 assert.ok((-h/2-y)/s>=b.minY-1e-8);assert.ok((h/2-y)/s<=b.maxY+1e-8);
}
test('real drag, zoom, locate, route focus and following all apply viewport-aware clamps',()=>{
 for(const h of [748,1030,1348]){
  const c=boundedCamera(h);c.locate();assertViewport(c);
  c.setRider([-4529,-1409],45);assertViewport(c);
  c.touchStart(touch(1,0));c.touchMove(touch(1,100000,100000));assertViewport(c);c.touchEnd(touch(1,0));
  c.zoom(.3);assertViewport(c);c.zoom(3);assertViewport(c);c.overview();assertViewport(c);
  c.locate();assertViewport(c);
  c.routes=[{points:[[-4500,-1400],[-600,1100]]}];c.focusRoute();assertViewport(c);
 }
});
test('legacy outside rider and route remain visible in a continuous compatibility camera',()=>{
 const c=boundedCamera();c.routes=[{points:[[1490,-3333],[-1540,-130]]}];
 c.setRider([1490,-3333],0);c.locate();
 const p=c.project(c.riderPoint);assert.ok(Math.abs(p[0])<=360&&Math.abs(p[1])<=674);
 c.setRider([1000,-3000],45);const next=c.project(c.riderPoint);assert.ok(Math.abs(next[0])<=360&&Math.abs(next[1])<=674);
});

test('spreading two fingers around a stationary midpoint keeps that map point pinned',()=>{
 const city=camera();
 city.touchStart(touch(1,-100));city.touchStart(touch(2,100));
 city.touchMove(touch(1,-200));city.touchMove(touch(2,200));
 assert.equal(city.scale,2);
 assert.ok(Math.hypot(...city.offset)<1e-8);
});

test('the pinch midpoint remains stable when zoom reaches its upper limit',()=>{
 const city=camera(2);
 city.touchStart(touch(1,-100));city.touchStart(touch(2,100));
 city.touchMove(touch(1,-300));city.touchMove(touch(2,300));
 assert.equal(city.scale,2);
 assert.ok(Math.hypot(...city.offset)<1e-8);
});


test('locating for departure restores fifty metres and every overview or route camera stays within thirty to one hundred metres',()=>{
 const city=camera(.65);
 Object.assign(city,{riderPoint:[1200,-300],data:{width:12000,height:12000},mapHeight:748,routes:[{points:[[0,0],[10000,10000]]}]});
 city.locate(true);assert.equal(city.scale,1.2);assert.equal(city.follow,true);
 assert.deepEqual(Array.from(city.offset),[-1440,360]);
 city.zoom(.0001);assert.equal(city.scale,.6);
 city.zoom(10000);assert.equal(city.scale,2);
 city.overview();assert.equal(city.scale,.6);
 city.focusRoute();assert.ok(city.scale>=.6&&city.scale<=2);
});
